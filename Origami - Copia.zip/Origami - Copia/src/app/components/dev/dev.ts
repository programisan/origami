import { Component } from '@angular/core';

@Component({
  selector: 'app-dev',
  standalone: true,
  imports: [],
  templateUrl: './dev.html',
  styleUrl: './dev.css',
})
export class WikiDev {}
