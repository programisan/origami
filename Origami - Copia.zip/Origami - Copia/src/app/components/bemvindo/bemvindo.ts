import { Component } from '@angular/core';

@Component({
  standalone: true,
  templateUrl: './bemvindo.html',
})
export class WikiBemVindo {}
