import { Component } from '@angular/core';

@Component({
  selector: 'app-links',
  standalone: true,
  imports: [],
  templateUrl: './links.html',
  styleUrl: './links.css'
})
export class WikiLinks {

}
