import { Component } from '@angular/core';

@Component({
  selector: 'app-negocios',
  standalone: true,
  imports: [],
  templateUrl: './negocios.html',
  styleUrl: './negocios.css'
})
export class WikiNegocios {

}
